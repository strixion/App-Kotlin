package com.example.strixionai.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.example.strixionai.R

class ScannerFragment : Fragment() {
    private lateinit var imageView: ImageView
    private lateinit var scanButton: Button
    private val REQUEST_IMAGE_CAPTURE = 1
    private val CAMERA_PERMISSION_REQUEST_CODE = 100

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_scanner, container, false)
        imageView = view.findViewById(R.id.image_view)
        scanButton = view.findViewById(R.id.scan_button)

        scanButton.setOnClickListener {
            if (checkCameraPermission()) {
                dispatchTakePictureIntent()
            } else {
                requestCameraPermission()
            }
        }
        return view
    }

    private fun checkCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST_CODE)
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(requireActivity().packageManager) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            imageView.setImageBitmap(imageBitmap)

            // Обработка изображения и получение исправленного текста
            val correctedText = processImageAndGetCorrectedText(imageBitmap)

            // Вызов метода для отображения диалога с исправленным текстом
            showCorrectedTextDialog(correctedText)
        }
    }

    private fun processImageAndGetCorrectedText(image: Bitmap): String {
        // Здесь ваша логика обработки изображения
        // Например, вы можете использовать OCR для извлечения текста
        // На данный момент возвращаем статический текст для примера
        return "Исправленный текст из изображения"
    }

    private fun showCorrectedTextDialog(correctedText: String) {
        val dialog = CorrectedTextDialog(correctedText)
        dialog.show(requireFragmentManager(), "CorrectedTextDialog")
    }

    // Обработка результата запроса разрешения
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Разрешение предоставлено, запускаем камеру
                dispatchTakePictureIntent()
            } else {
                // Разрешение отказано, можно показать сообщение пользователю
            }
        }
    }
}

class CorrectedTextDialog(private val correctedText: String) : DialogFragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.dialog_corrected_text, container, false)
        val textView = view.findViewById<TextView>(R.id.corrected_text_view)
        val confirmButton = view.findViewById<Button>(R.id.confirm_button)
        val closeButton = view.findViewById<Button>(R.id.close_button)

        textView.text = correctedText
        confirmButton.setOnClickListener { dismiss() }
        closeButton.setOnClickListener { dismiss() }
        return view
    }
}
